package org.tekkotsu.ui.editor.debug;

public class TestResource {

}
