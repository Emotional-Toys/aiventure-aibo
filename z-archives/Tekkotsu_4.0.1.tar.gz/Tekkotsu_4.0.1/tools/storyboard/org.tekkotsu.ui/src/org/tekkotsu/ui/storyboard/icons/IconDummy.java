package org.tekkotsu.ui.storyboard.icons;

public class IconDummy {

}
