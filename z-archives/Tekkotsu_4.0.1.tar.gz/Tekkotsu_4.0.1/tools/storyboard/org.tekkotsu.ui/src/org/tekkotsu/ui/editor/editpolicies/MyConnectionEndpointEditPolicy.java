/*
 * Created on Sep 19, 2004
 */
package org.tekkotsu.ui.editor.editpolicies;

import org.eclipse.gef.editpolicies.ConnectionEndpointEditPolicy;

/**
 * @author asangpet
 */
public class MyConnectionEndpointEditPolicy extends
		ConnectionEndpointEditPolicy {

}
