package org.tekkotsu.ui.editor.icons;

public class IconDummy {

}
