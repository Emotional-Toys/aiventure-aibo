/*
 * Created on Dec 22, 2004
 */
package org.tekkotsu.ui.editor;

import org.eclipse.draw2d.PolylineConnection;

/**
 * @author asangpet
 *
 */
public class MyPolylineConnection extends PolylineConnection implements
		TransitionConnection {

}
