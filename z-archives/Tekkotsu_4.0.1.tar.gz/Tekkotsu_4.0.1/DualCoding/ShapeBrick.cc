//-*-c++-*-
#include <iostream>

#include "SketchSpace.h"

#include "ShapeBrick.h"

namespace DualCoding {

SHAPESTUFF_CC(BrickData);

} // namespace
