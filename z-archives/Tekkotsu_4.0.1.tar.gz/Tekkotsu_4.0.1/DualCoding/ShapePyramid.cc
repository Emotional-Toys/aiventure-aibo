//-*-c++-*-
#include <iostream>

#include "SketchSpace.h"

#include "ShapePyramid.h"

namespace DualCoding {

SHAPESTUFF_CC(PyramidData);

} // namespace
