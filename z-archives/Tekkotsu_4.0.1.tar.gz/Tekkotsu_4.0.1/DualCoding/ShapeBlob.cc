//-*-c++-*-

#include "ShapeSpace.h"

#include "ShapeBlob.h"

namespace DualCoding {

SHAPESTUFF_CC(BlobData);    // defined in ShapeRoot.h

} // namespace
