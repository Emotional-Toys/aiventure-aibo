//-*-c++-*-
#include <iostream>

using namespace std;

#include "SketchSpace.h"

#include "ShapeLocalizationParticle.h"

namespace DualCoding {

SHAPESTUFF_CC(LocalizationParticleData);

} // namespace
