//-*-c++-*-

#include "SketchSpace.h"
#include "ShapeSpace.h"

#include "Point.h"
#include "BaseData.h"
#include "AgentData.h"

#include "ShapeAgent.h"

namespace DualCoding {

SHAPESTUFF_CC(AgentData);

} // namespace
