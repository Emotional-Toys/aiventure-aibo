//-*-c++-*-
#include <iostream>

#include "SketchSpace.h"

#include "ShapePoint.h"

namespace DualCoding {

SHAPESTUFF_CC(PointData);

} // namespace
