#include <iostream>

#include "SketchSpace.h"
#include "ShapeSpace.h"
#include "ShapeLine.h"

#include "PolygonData.h"
#include "ShapePolygon.h"

namespace DualCoding {

SHAPESTUFF_CC(PolygonData);
	
} // namespace
