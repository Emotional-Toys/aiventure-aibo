//-*-c++-*-

#include "ShapeTarget.h"

namespace DualCoding {

SHAPESTUFF_CC(TargetData);   // defined in ShapeRoot.h

} // namespace
