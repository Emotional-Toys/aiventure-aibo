#include "TimeET.h"

struct timezone TimeET::tz={0,0};

/*! @file
 * @brief Implements TimeET, a nice class for handling time values with high precision (but all that's in the .cc is implementation of struct timezone TimeET::tz)
 * @author ejt (Creator)
 *
 * $Author: ejt $
 * $Name: tekkotsu-4_0-branch $
 * $Revision: 1.4 $
 * $State: Exp $
 * $Date: 2006/03/15 16:44:07 $
 */

