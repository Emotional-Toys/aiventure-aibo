#ifdef __Z8001__

segm
#define PARG_0 rr6
#else
unsegm
#define PARG_0 r7
#endif

#define LARG_0 rr6
#define ARG_0 r7

#define LARG_1 rr4
